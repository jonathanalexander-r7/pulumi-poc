def hello_pulumi():
    print("Hello Pulumi")
